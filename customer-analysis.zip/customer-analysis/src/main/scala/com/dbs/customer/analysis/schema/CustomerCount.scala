package com.dbs.customer.analysis.schema

/**
 * Created By: Srikanth.nelluri
 * Date: 10-08-2019
 */
case class CustomerCount(customer_first_name: String,
                         customer_last_name: String,
                         count: Int)
