package com.dbs.customer.analysis.schema

/**
 * Created By: Srikanth.nelluri
 * Date: 10-08-2019
 */
case class FilteredUsers(customer_id: Long,
                         count: Int)
