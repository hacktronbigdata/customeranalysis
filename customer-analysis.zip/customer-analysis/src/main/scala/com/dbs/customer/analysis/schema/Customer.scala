package com.dbs.customer.analysis.schema

/**
 * Created By: Srikanth.nelluri
 * Date: 10-08-2019
 */
case class Customer(customer_id: Long,
                    customer_first_name: String,
                    customer_last_name: String,
                    phone_number: Long)
